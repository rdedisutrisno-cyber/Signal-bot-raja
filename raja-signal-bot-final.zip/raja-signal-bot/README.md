# Raja Signal Bot

Bot Telegram signal EUR/USD M5.

## Deploy Railway

1. Upload project ke GitHub.
2. Login Railway.
3. New Project -> Deploy from GitHub Repo.
4. Tambahkan Environment Variables:
   - BOT_TOKEN
   - CHAT_ID
   - TWELVE_API_KEY
5. Deploy.

Bot akan mengirim BUY / SELL / NO TRADE setiap 5 menit.
