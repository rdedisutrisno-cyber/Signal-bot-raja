import requests
import pandas as pd
import time
from telegram import Bot
from config import BOT_TOKEN, CHAT_ID, TWELVE_API_KEY

bot = Bot(BOT_TOKEN)
last_signal = None

def get_data():
    url = (
        f"https://api.twelvedata.com/time_series?symbol=EUR/USD&interval=5min&outputsize=100&apikey={TWELVE_API_KEY}"
    )
    data = requests.get(url, timeout=15).json()

    if "values" not in data:
        raise Exception(data)

    df = pd.DataFrame(data["values"])
    df = df.iloc[::-1]
    df["close"] = df["close"].astype(float)
    return df

def ema(series, period):
    return series.ewm(span=period, adjust=False).mean()

def rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0).rolling(period).mean()
    loss = (-delta.clip(upper=0)).rolling(period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

while True:
    try:
        df = get_data()
        close = df["close"]

        ema20 = ema(close, 20)
        ema50 = ema(close, 50)
        r = rsi(close)

        signal = "NO TRADE"

        if ema20.iloc[-1] > ema50.iloc[-1] and r.iloc[-1] > 55:
            signal = "BUY"
        elif ema20.iloc[-1] < ema50.iloc[-1] and r.iloc[-1] < 45:
            signal = "SELL"

        if signal != last_signal:
            price = close.iloc[-1]
            message = (
                f"EUR/USD M5\n"
                f"Signal: {signal}\n"
                f"Price: {price:.5f}\n"
                f"EMA20: {ema20.iloc[-1]:.5f}\n"
                f"EMA50: {ema50.iloc[-1]:.5f}\n"
                f"RSI: {r.iloc[-1]:.2f}"
            )
            bot.send_message(chat_id=CHAT_ID, text=message)
            last_signal = signal

    except Exception as e:
        bot.send_message(chat_id=CHAT_ID, text=f"Bot Error: {e}")

    time.sleep(300)
